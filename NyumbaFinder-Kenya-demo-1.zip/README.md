# NyumbaFinder Kenya — Demo
Fungua `index.html` kwenye browser kuiona.

Ina:
- Search kwa location
- Filter kwa aina ya nyumba
- Filter kwa maximum rent
- Sort kwa bei
- Property cards na picha
- Save/Contact demo buttons
- Form ya ku-post nyumba

Next stage inaweza kuongeza:
1. Database + landlord accounts
2. WhatsApp/phone contact
3. GPS/Google Maps
4. Image upload
5. Verification ya listings
6. Notifications
7. Admin dashboard
8. Online payments/subscriptions
